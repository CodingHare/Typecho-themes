## 注意 ##
插件文件夹名称必须是Prismjs，否则不能生效。

## 用法 ##
使用方法很簡單，只要在\`\`\`或者\`之後輸入相應的語言即可，例如：
<pre>
```c#
Console.Write("Hello World!");
```
</pre>
或者行內代碼：
<pre>
`js console.log("Hi!");`
</pre>

## 效果 ##
![block.png][1]
![inline.png][2]

## 後台參數 ##
後台可以修改的參數如下：

![settings.png][3]

  [1]: http://i.imgur.com/UslS8xP.png
  [2]: http://i.imgur.com/X7NDEHh.png
  [3]: http://i.imgur.com/4Tnrm9v.png
